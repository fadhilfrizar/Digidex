//
//  Info.swift
//  RickAndMorty
//
//  Created by USER-MAC-GLIT-007 on 16/02/23.
//

import Foundation

struct InfoModel: Codable {
    let count: Int
    let pages: Int
    let next: String
    let prev: String
}
